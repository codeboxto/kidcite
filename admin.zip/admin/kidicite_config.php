<?php
$lhost="localhost";
$user="root";
$pswd="";
$dbname="kidicite";
$kidicite_config=mysqli_connect($lhost,$user,$pswd,$dbname);
	if (!$kidicite_config)
	{
		echo "Failed to connect:".mysqli_connect_error();
	}
	

?>