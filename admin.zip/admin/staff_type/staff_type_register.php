<?php
if (isset($_POST["enter"]))
{
	require("../kidicite_config.php");
	$staff_type_code=$_POST["staff_type_code"];
	$role=$_POST["role"];    

	$staff_type_info_sql = "INSERT INTO staff_type(staff_type_id,role) 
	VALUES ('$staff_type_code','$role')";

    if ($kidicite_config->query($staff_type_info_sql) === TRUE) {
       header ("location:view_role.php");
    } else {
        echo "Failed insert:".mysqli_connect_error($kidicite_config);

}
}
?>