<?php
if (isset($_POST["enter"]))
{
	$kidicite_config=mysqli_connect("localhost","root","","kidicite");
	$class_detail_name=$_POST["class_detail_name"];
	$class_id=$_POST["class_id"];    
	$subject_id=$_POST["subject_id"];
	$description=$_POST["description"];  
	$detail_status=$_POST["detail_status"]; 
    
	$class_info_sql = "INSERT INTO class_detail(class_detail_name,class_id,s_id,class_description,detail_status) 
	VALUES ('$class_detail_name','$class_id','$subject_id','$description','$detail_status')";

    if ($kidicite_config->query($class_info_sql) === TRUE) {
       header ("location:view_class_detail.php");
    } else {
        echo "Failed insert:".mysqli_connect_error($kidicite_config);

}
}
?>