<?php
require("../kidicite_config.php");
$sql_course="select * from subject";
$result1=mysqli_query($kidicite_config,$sql_course);

$sql_class="select * from class";
$result2=mysqli_query($kidicite_config,$sql_class);
?>
<!Doctype html>

<html lang="en">

<head>
      <!--header-->
      <?php include("../assets/header_links/form_header.php");?>
    <!-- End of header -->
    <title>Kidicite &mdash; Course Page</title>
    
</head>
<?php

$class_detail_id = "";                    
$class_detail_name = "";
$class_name = "";
$subject_name = "";
$class_description = "";
$detail_status = "";
require("../kidicite_config.php");

$class_detail_id =isset($_GET['class_detail_id'])? $_GET['class_detail_id'] : "";
$class_detail_name= isset($_GET['class_detail_name'])? $_GET['class_detail_name'] : ""; 
$class_name = isset($_GET['class_name'])? $_GET['class_name'] : "";
$subject_name= isset($_GET['subject_name'])? $_GET['subject_name'] : ""; 
$class_description = isset($_GET['class_description'])? $_GET['class_description'] : "";
$detail_status= isset($_GET['detail_status'])? $_GET['detail_status'] : "";  
?>
<body>
    <div class="wrapper">
        <div class="auth-content">
            <div class="card">
                <div class="card-body text-center">
                    <div class="mb-4">
                        <img class="brand" src="../assets/img/logo_transparent.png" width="120px" height="120px" alt="bootstraper logo">
                    </div>
                    <h6 class="mb-4 text-muted">Update Class Detail Data</h6>
                    <form action="upate_class_detail.php" method="post">
                         <div class="mb-3 text-start">
                            <input type="hidden" class="form-control"  name="class_detail_id" value="<?php echo $class_detail_id;?>" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Class Detail Name</label>
                            <input type="text" class="form-control" placeholder="Class Detail Name" name="class_detail_name" value="<?php echo $class_detail_name;?>" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Class Name </label>
                            <select name="class_id" class="form-select" >
								<?php

									while ($rows = mysqli_fetch_array($result2)):;
								?>
									<option value="<?php echo $rows[0];?>"><?php echo $rows[1];?></option>

									<?php  endwhile; ?>
                                     </select>
                        </div>                        
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Subject Name </label>
                            <select name="subject_id" class="form-select" >
								<?php

									while ($rows = mysqli_fetch_array($result1)):;
								?>
									<option value="<?php echo $rows[0];?>"><?php echo $rows[2];?></option>

									<?php  endwhile; ?>
                                     </select>
                        </div> 
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Description </label>
                            <input type="text" class="form-control" placeholder="Class Detail Description" name="description" value="<?php echo $class_description;?>" required>
                        </div>                        
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Status</label>
                            <select name="detail_status" class="form-select" required>
                            <option value="Open">Open</option>
                            <option value="Close">Close</option>
                            </select>
                        </div>                        
                        <button class="btn btn-primary shadow-2 mb-4" name="enter">Update Class Detail</button>
                    </form>
                    <button class="btn btn-success shadow-2 mb-4"><a href="view_class_detail.php">Back To View Class Detail</a></button>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>