<?php
session_start();
$name=$_SESSION['name'];       
$email=$_SESSION['email'];
$password= $_SESSION['password'];
require("../kidicite_config.php");
$sql="Select admin_email,admin_password from admin where admin_email='$email' && admin_password='$password'";
$result= $kidicite_config->query($sql);
if(!$result)
{
    echo "Error updating record: " . $kidicite_config->error;
}

?>
<?php
require("../kidicite_config.php");
$sql_course="select * from subject";
$result1=mysqli_query($kidicite_config,$sql_course);

?>
<!Doctype html>

<html lang="en">

<head>
      <!--header-->
      <?php include("../assets/header_links/form_header.php");?>
    <!-- End of header -->
    <title>Kidicite &mdash; Class Page</title>
    
</head>

<body>
    <div class="wrapper">
        <div class="auth-content">
            <div class="card">
                <div class="card-body text-center">
                    <div class="mb-4">
                        <img class="brand" src="../assets/img/logo_transparent.png" width="120px" height="120px" alt="bootstraper logo">
                    </div>
                    <h6 class="mb-4 text-muted">Register Class Data</h6>
                    <form action="class_data.php" method="post">
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Class Name</label>
                            <input type="text" class="form-control" placeholder="Class Name" name="class_name" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Is Detail </label>
                            <select name="class_detail" class="form-select" required>
                            <option value="Open">Open</option>
                            <option value="Close">Close</option>
                            </select>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Calss Description </label>
                            <input type="text" class="form-control" placeholder="Class Description" name="class_desc" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Subject Name </label>
                            <select name="subject_id"  class="form-select" >
								<?php

									while ($rows = mysqli_fetch_array($result1)):;
								?>
									<option value="<?php echo $rows[0];?>"><?php echo $rows[2];?></option>

									<?php  endwhile; ?>
                                     </select>
                        </div>                         
                        <button class="btn btn-primary shadow-2 mb-4" name="enter">Register Class</button>
                    </form>
                    <button class="btn btn-success shadow-2 mb-4"><a href="view_class.php">Back To View Class</a></button>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>