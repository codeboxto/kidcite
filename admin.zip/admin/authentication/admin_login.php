
<!doctype html>
<html lang="en">

<head>
         <!--header-->
<?php include("../assets/header_links/form_header.php");?>
    <!-- End of header -->
    <title>Kidicite &mdash; Admin Login Page</title>
    
</head>
<body>
    <div class="wrapper">
    
        <div class="auth-content">
            <div class="card">
                <div class="card-body text-center">
                    <div class="mb-4">
                        <img class="brand" src="../assets/img/logo_transparent.png" width="120px" height="120px" alt="bootstraper logo">
                    </div>
                    <h6 class="mb-4 text-muted">Admin Login</h6>
                    <h6 class="mb-4 text-muted">Login to your account</h6>
                    <form action="admin_login_data.php" method="post">
                        <div class="mb-3 text-start">
                            <label for="email" class="form-label">Email adress</label>
                            <input type="email" class="form-control" placeholder="Enter Email" name="admin_email" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" placeholder="Password" name="admin_password" required>
                        </div>
                        <button class="btn btn-primary shadow-2 mb-4" name="enter">Login</button>
                        <br>
                        <button class="btn btn-primary shadow-2 mb-4" name="enter"><a href="../../user/index.php">Back To Home</a></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="../assets/vendor/jquery/jquery.min.js"></script>
    <script src="../assets/vendor/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>