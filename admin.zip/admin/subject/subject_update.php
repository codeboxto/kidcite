<!doctype html>
<html lang="en">

<head>
      <!--header-->
      <?php include("../assets/header_links/form_header.php");?>
    <!-- End of header -->
    <title>Kidicite &mdash; Subject Update Page</title>
    
</head>

<body>
    <div class="wrapper">
        <div class="auth-content">
            <div class="card">
                <div class="card-body text-center">
                    <div class="mb-4">
                        <img class="brand" src="../assets/img/logo_transparent.png" width="120px" height="120px" alt="bootstraper logo">
                    </div>
                    <?php
$s_id = "";                    
$subject_id = "";
$subject_name = "";
$subject_status = "";
require("../kidicite_config.php");
$s_id = isset($_GET['s_id'])? $_GET['s_id'] : "";
$subject_id = isset($_GET['subject_id'])? $_GET['subject_id'] : "";
$subject_name= isset($_GET['subject_name'])? $_GET['subject_name'] : "";
$subject_status = isset($_GET['subject_status'])? $_GET['subject_status'] : "";

?>

                    <h6 class="mb-4 text-muted">Update Subject Data</h6>
                    <form action="subject_update_data.php" method="post">
                    <input type="hidden" class="form-control" value="<?php echo $s_id;?>"  name="sid" >
                        <div class="mb-3 text-start">
                            <label for="id" class="form-label">Subject ID</label>
                            <input type="text" class="form-control" placeholder="Enter Subject ID" value="<?php echo $subject_id;?>"  name="subject_id" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Subject Name</label>
                            <input type="text" class="form-control" placeholder="Subject Name" value="<?php echo $subject_name;?>"  name="subject_name" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="status" class="form-label">Subject Status</label>
                             <select name="subject_status" value="<?php echo $course_status;?>" class="form-select" required>    
                            <option value="open">Open</option>
                            <option value="close">Close</option>
                            </select> 
                        </div>                      
                        <button class="btn btn-primary shadow-2 mb-4" name="enter">Update</button>
                    </form>
                    <button class="btn btn-success shadow-2 mb-4"><a href="view_course.php">Back To View Subject</a></button>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>