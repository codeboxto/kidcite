<?php
if (isset($_POST["enter"]))
{
	include("../kidicite_config.php");
	$s_id=$_POST["subject_id"];
	$s_name=$_POST["subject_name"];
	$s_status=$_POST["subject_status"];    
    
	$subject_info_sql = "INSERT INTO subject(subject_id,subject_name,subject_status) 
	VALUES ('$s_id','$s_name','$s_status')";

    if ($kidicite_config->query($subject_info_sql) === TRUE) {
       header ("location:view_subject.php");
    } else {
        echo "Failed insert:".mysqli_connect_error($kidicite_config);

}
}
?>