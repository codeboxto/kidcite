<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style2.css">
	<title></title>
</head>
<body>
<div class="header">
	<h2>Admin Login</h2>
</div>
<form method="post" action="login_data.php">
	<div class="input-group">
		<label>Email</label>
		<input type="email" name="email" value="">
	</div>
	<div class="input-group">
		<label>Password</label>
		<input type="password" name="password">
	</div>
	<div class="input-group">
		<button type="submit" class="btn" name="login_btn">Login</button>
	</div>
</form>
</body>
</html>