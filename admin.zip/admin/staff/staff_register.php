<?php
require("../kidicite_config.php");
if(isset($_POST['enter'])){

	$staff_code = $kidicite_config->real_escape_string(trim($_POST['staff_code']));
	$stype_id = $kidicite_config->real_escape_string(trim($_POST['stype_id']));    
	$staff_name = $kidicite_config->real_escape_string(trim($_POST['staff_name']));
	$letter_quotes =  $kidicite_config->real_escape_string(trim($_POST['letter_quotes']));

	
	$tmp_name = $_FILES["image"]["tmp_name"];
	$filename = basename($_FILES["image"]["name"]);

	$target_dir = "../upload";
	move_uploaded_file($tmp_name, "$target_dir/$filename");


	$query = "INSERT INTO staff (staff_code, id, staff_name,letter_quotes,image)
		VALUES ('{$staff_code}', '{$stype_id}', '{$staff_name}', '{$letter_quotes}', '{$filename}')";

	$result = $kidicite_config->query($query);
	
	if ($kidicite_config->query($result) === TRUE) {
        header ("location:view_staff.php");
     } else {
	  echo "Error: " . $result . "<br>" . $kidicite_config->error;
	}

}
?>