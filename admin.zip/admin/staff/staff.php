<?php
session_start();
$name=$_SESSION['name'];       
$email=$_SESSION['email'];
$password= $_SESSION['password'];
require("../kidicite_config.php");
$sql="Select admin_email,admin_password from admin where admin_email='$email' && admin_password='$password'";
$result= $kidicite_config->query($sql);
if(!$result)
{
    echo "Error updating record: " . $kidicite_config->error;
}

?>
<?php
require("../kidicite_config.php");
$sql_role="select * from staff_type";
$result1=mysqli_query($kidicite_config,$sql_role);

?>
<!doctype html>

<html lang="en">

<head>
      <!--header-->
      <?php include("../assets/header_links/form_header.php");?>
    <!-- End of header -->
    <title>Kidicite &mdash; Staff Register Page</title>
    
</head>

<body>
    <div class="wrapper">
        <div class="auth-content">
            <div class="card">
                <div class="card-body text-center">
                    <div class="mb-4">
                        <img class="brand" src="../assets/img/logo_transparent.png" width="120px" height="120px" alt="bootstraper logo">
                    </div>
                    <h6 class="mb-4 text-muted">Register Staff Data</h6>
                    <form action="staff_register.php" method="post" enctype="multipart/form-data">
                        <div class="mb-3 text-start">
                            <label for="id" class="form-label">Staff Code</label>
                            <input type="text" class="form-control" placeholder="Enter staff Code" name="staff_code" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Role</label>
                            <select name="stype_id"  class="form-select" >
								<?php

									while ($rows = mysqli_fetch_array($result1)):;
								?>
									<option value="<?php echo $rows[0];?>"><?php echo $rows[2];?></option>

									<?php  endwhile; ?>
                                     </select>
                        </div>   
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Staff Name</label>
                            <input type="text" class="form-control" placeholder="staff Name" name="staff_name"  required>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="email" class="form-label">Staff Letter Quotes</label>
                            
                            <textarea class="form-control" name="letter_quotes"  required></textarea>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="password" class="form-label">Staff Image</label>
                            <br>
                            <input type="file" class="form-control" placeholder="Enter staff Image" name="image"  required>
                        </div>                    
                        <button class="btn btn-primary shadow-2 mb-4" name="enter">Register</button>
                    </form>
                    <button class="btn btn-success shadow-2 mb-4"><a href="view_staff.php">Back To View Staff</a></button>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>