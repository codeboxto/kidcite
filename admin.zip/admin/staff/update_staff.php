<?php

require("../kidicite_config.php");
$staff_id = $_GET['s_id'];
$staff_code = "";
$staff_name = "";
$role="";
$letter_quotes="";

$query = "select s.s_id,s.staff_code ,s.staff_name, st.role,s.letter_quotes,s.image 
from staff s, staff_type st where st.id=s.id and s.s_id=$staff_id";
			$result = $kidicite_config->query($query) or die($kidicite_config->error);

if($result->num_rows > 0){
	while($row = $result->fetch_assoc()) {
        $staff_id = $row['s_id'];
		$staff_code = $row['staff_code'];
		$staff_name = $row['staff_name'];
		$position = $row['role'];
        $letter_quotes = $row['letter_quotes'];
		$image = $row['image'];
		
  	}
}else{	
	echo "no data";
}

$sql="select * from staff_type";
$result=$kidicite_config->query($sql)


?>
<!Doctype html>

<html lang="en">

<head>
      <!--header-->
      <?php include("../assets/header_links/form_header.php");?>
    <!-- End of header -->
    <title>Kidicite &mdash; Course Page</title>
    
</head>

<body>
    <div class="wrapper">
        <div class="auth-content">
            <div class="card">
                <div class="card-body text-center">
                    <div class="mb-4">
                        <img class="brand" src="../assets/img/logo_transparent.png" width="120px" height="120px" alt="bootstraper logo">
                    </div>
                    <h6 class="mb-4 text-muted">Update Staff Data</h6>
                    <form action="staff_data_update.php" method="post">
                          <div class="mb-3 text-start">
                            
                            <input type="hidden" class="form-control"  name="staff_id" value="<?php echo $staff_id;?>">
                        </div>
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Staff Code</label>
                            <input type="text" class="form-control" placeholder="Staff Code" name="staff_code" value="<?php echo $staff_code;?>" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Staff Name</label>
                            <input type="text" class="form-control" placeholder="Staff Name" name="staff_name" value="<?php echo $staff_name;?>" required>
                        </div>

                      
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Role </label>
                            <select name="position" value="<?php echo $position;?>" class="form-select"  >
								<?php

									while ($rows = mysqli_fetch_array($result)):;
								?>
									<option value="<?php echo $rows[0];?>"><?php echo $rows[2];?></option>

									<?php  endwhile; ?>
                                     </select>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Letter Quotes</label>
                            <textarea name="letter_quotes" class="form-control" required ><?php echo $letter_quotes;?></textarea>
                        </div>  
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Profile Photo</label>
                            <input type="file" class="form-control" name="newimage">
                        </div>  
                        <div class="mb-3 text-start">
                            
                            <input type="hidden" name="oldimage" value="<?php echo $image;?>">
                        </div>                                              
                        <button class="btn btn-primary shadow-2 mb-4" name="enter">Upate Class</button>
                    </form>
                    <button class="btn btn-success shadow-2 mb-4"><a href="view_staff.php">Back To View Staff</a></button>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>