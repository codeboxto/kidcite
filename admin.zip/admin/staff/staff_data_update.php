<?php
require("../kidicite_config.php");

$staff_id = $_POST['staff_id'];


$staff_code = $kidicite_config->real_escape_string(trim($_POST['staff_code']));
$staff_name =  $kidicite_config->real_escape_string(trim($_POST['staff_name']));
$role       = $kidicite_config->real_escape_string(trim($_POST['position']));
$letter_quotes =  $kidicite_config->real_escape_string(trim($_POST['letter_quotes']));


$filename = $_FILES['newimage']['name'];

if(move_uploaded_file($_FILES['newimage']['tmp_name'],'../upload/'.$filename))

{
	$query = "UPDATE staff SET 
    staff_code='$staff_code',
    staff_name='$staff_name',
    id='$role',
    letter_quotes='$letter_quotes',
     image='$filename' WHERE
     s_id='$staff_id' ";
	
if (mysqli_query($kidicite_config, $query)) {
	header("Location: view_staff.php");
} else {
  echo "Error updating record: " . $kidicite_config->error;
}
}

 if (isset($_POST['oldimage']))
{
	header("Location:view_staff.php");
} else {
  echo "Error updating record: " . $kidicite_config->error;
}	

$kidicite_config->close();

?>