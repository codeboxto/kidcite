
	<?php
	if (isset($_POST["login_btn"]))
{
		$con=new mysqli("localhost","root","","upload");
			$a_email = $_POST["email"];
			$a_psw = $_POST["password"];

$sql_login= $con->query("Select admin_email,admin_password from admin where admin_email='$a_email' and admin_password='$a_psw' "); 

if (mysqli_num_rows($sql_login) >0)
    {
    while($row = mysqli_fetch_assoc($sql_login))
   
 header ("location:pdf_upload.php");
}
else 
{
   echo"You are not Admin!!";

    }
    }
	?>
	
