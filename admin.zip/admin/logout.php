<?php
session_start();
unset($_SESSION["name"]);
unset($_SESSION["email"]);
unset($_SESSION["password"]);
header("Location:authentication/admin_login.php");

?>