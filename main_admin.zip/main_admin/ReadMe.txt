Admin Side
-Insert Student Data
-Insert/Update Course Data
-Insert/Update Class Data
-Insert/Update Class Detail Data
-Insert/Update Batch Data