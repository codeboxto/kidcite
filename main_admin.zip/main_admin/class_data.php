<?php
if (isset($_POST["enter"]))
{
	$kidicite_config=mysqli_connect("localhost","root","","kidicite");
	$class_name=$_POST["class_name"];
	$class_detail=$_POST["class_detail"];    
	$class_desc=$_POST["class_desc"];
	$course_id=$_POST["course_id"];  
    
	$class_info_sql = "INSERT INTO class(class_name,class_detail,class_description,k_course_id) 
	VALUES ('$class_name','$class_detail','$class_desc','$course_id')";

    if ($kidicite_config->query($class_info_sql) === TRUE) {
       header ("location:view_class.php");
    } else {
        echo "Failed insert:".mysqli_connect_error($kidicite_config);

}
}
?>