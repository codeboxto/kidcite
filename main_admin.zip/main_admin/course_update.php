<!doctype html>
<!-- 
* Bootstrap Simple Admin Template
* Version: 2.1
* Author: Alexis Luna
* Website: https://github.com/alexis-luna/bootstrap-simple-admin-template
-->
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Kidicite &mdash; Update Course Page</title>
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/auth.css" rel="stylesheet">
</head>

<body>
    <div class="wrapper">
        <div class="auth-content">
            <div class="card">
                <div class="card-body text-center">
                    <div class="mb-4">
                        <img class="brand" src="assets/img/logo_transparent.png" width="120px" height="120px" alt="bootstraper logo">
                    </div>
                    <?php
$kidicite_config=mysqli_connect("localhost","root","","kidicite");

$cid = $_GET['course_id'];
$cname= $_GET['course_name']; 
$cstatus = $_GET['course_status'];
?>
                    <h6 class="mb-4 text-muted">Update Course Data</h6>
                    <form action="course_update_data.php" method="post">
                        <div class="mb-3 text-start">
                            <label for="id" class="form-label">Course ID</label>
                            <input type="text" class="form-control" placeholder="Enter Courses ID" value="<?php echo $cid;?>"  name="course_id" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Course Name</label>
                            <input type="text" class="form-control" placeholder="Course Name" value="<?php echo $cname;?>"  name="course_name" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="status" class="form-label">Course Status</label>
                             <select name="course_status" required>    
                            <option value="open">Open</option>
                            <option value="close">Close</option>
                            </select> 
                        </div>                      
                        <button class="btn btn-primary shadow-2 mb-4" name="enter">Update</button>
                    </form>
                    <p class="mb-2 text-muted">View Course Data<a href="view_course.php">Click Here!</a></p>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>