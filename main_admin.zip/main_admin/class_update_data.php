<?php
$kidicite_config=mysqli_connect("localhost","root","","kidicite");

$clas_id=$_POST['class_id'];
$class_name=$_POST['class_name'];
$class_detail=$_POST['class_detail'];
$class_description=$_POST['class_desc'];
$course_id=$_POST['course_id'];

	$update_result=mysqli_query($kidicite_config," UPDATE class SET  class_name='$class_name',
    class_detail='$class_detail',
    class_description='$class_description',
    k_course_id='$course_id'
    WHERE class_id='$clas_id'");
	if($update_result)
	{
	header('Location:view_class.php');
	}
else
	{
	echo "No Data";
	}
?>