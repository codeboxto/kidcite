-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 09, 2021 at 02:59 PM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `kidicite`
--

-- --------------------------------------------------------

--
-- Table structure for table `batch_code`
--

CREATE TABLE IF NOT EXISTS `batch_code` (
  `batch_id` int(11) NOT NULL,
  `batch_name` varchar(35) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `class_detail_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `batch_code`
--

INSERT INTO `batch_code` (`batch_id`, `batch_name`, `start_date`, `end_date`, `class_detail_id`) VALUES
(1, 'Batch1 Computer Basic              ', '2021-08-10', '2021-09-14', 2);

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE IF NOT EXISTS `class` (
  `class_id` int(11) NOT NULL,
  `class_name` varchar(35) NOT NULL,
  `class_detail` varchar(10) NOT NULL,
  `class_description` text NOT NULL,
  `k_course_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`class_id`, `class_name`, `class_detail`, `class_description`, `k_course_id`) VALUES
(1, 'Normal Class                       ', 'Open', 'Age is 10 to 12                                                                                                                                ', 1),
(2, 'Speaking Class                     ', 'Open', 'Age is 10 to 16                                                                              ', 2),
(4, 'Basic Japan Language               ', 'Open', 'Age is 10 to 14                                                                                                                         ', 3);

-- --------------------------------------------------------

--
-- Table structure for table `class_detail`
--

CREATE TABLE IF NOT EXISTS `class_detail` (
  `class_detail_id` int(11) NOT NULL,
  `class_detail_name` varchar(35) NOT NULL,
  `class_id` int(11) NOT NULL,
  `k_course_id` int(11) NOT NULL,
  `class_description` text NOT NULL,
  `detail_status` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class_detail`
--

INSERT INTO `class_detail` (`class_detail_id`, `class_detail_name`, `class_id`, `k_course_id`, `class_description`, `detail_status`) VALUES
(1, 'A2', 1, 2, 'Age is 10 to 12', 'Open'),
(2, 'A2 Flyer', 1, 2, 'Age is 10 to 14', 'Open'),
(3, 'Japanese langauge                  ', 4, 3, 'Age is 10 to 12                                                                               ', 'Open'),
(4, 'N5 Class                           ', 1, 1, 'Age is 10 to 20                                            ', 'Close');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE IF NOT EXISTS `course` (
  `k_course_id` int(11) NOT NULL,
  `course_id` varchar(6) NOT NULL,
  `course_name` varchar(30) NOT NULL,
  `course_status` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`k_course_id`, `course_id`, `course_name`, `course_status`) VALUES
(1, 'c12w', 'computer basic ', 'close'),
(2, 'c12', 'English-Normal Course', 'open'),
(3, 'J1234', 'Japanese Language Class', 'open');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `id` int(11) NOT NULL,
  `student_code` varchar(35) NOT NULL,
  `student_name` varchar(50) NOT NULL,
  `student_phone` varchar(20) NOT NULL,
  `student_email` varchar(35) NOT NULL,
  `student_password` varchar(20) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `date_of_birth` date NOT NULL,
  `nrc_no` varchar(50) NOT NULL,
  `student_status` varchar(30) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `student_code`, `student_name`, `student_phone`, `student_email`, `student_password`, `gender`, `date_of_birth`, `nrc_no`, `student_status`) VALUES
(1, 'A156', 'Min MIn', '09-973939821', 'min123@gmail.com', 'minmin123', 'male', '2000-09-18', '9/MaNaMa(N)00299', 'attending');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `batch_code`
--
ALTER TABLE `batch_code`
  ADD PRIMARY KEY (`batch_id`);

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`class_id`);

--
-- Indexes for table `class_detail`
--
ALTER TABLE `class_detail`
  ADD PRIMARY KEY (`class_detail_id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`k_course_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `batch_code`
--
ALTER TABLE `batch_code`
  MODIFY `batch_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `class_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `class_detail`
--
ALTER TABLE `class_detail`
  MODIFY `class_detail_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `k_course_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
