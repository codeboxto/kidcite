<?php
$kidicite_config=mysqli_connect("localhost","root","","kidicite");
$sql_course="select * from course";
$result=mysqli_query($kidicite_config,$sql_course);

?>
<!Doctype html>
<!-- 
* Bootstrap Simple Admin Template
* Version: 2.1
* Author: Alexis Luna
* Website: https://github.com/alexis-luna/bootstrap-simple-admin-template
-->
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Kidicite &mdash; Update Class Page</title>
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/auth.css" rel="stylesheet">
</head>
                    <?php
$kidicite_config=mysqli_connect("localhost","root","","kidicite");

$class_id = $_GET['class_id'];
$class_name= $_GET['class_name']; 
$class_detail = $_GET['class_detail'];
$class_description= $_GET['class_description']; 
$course_name = $_GET['course_name'];    
?>
<body>
    <div class="wrapper">
        <div class="auth-content">
            <div class="card">
                <div class="card-body text-center">
                    <div class="mb-4">
                        <img class="brand" src="assets/img/logo_transparent.png" width="120px" height="120px" alt="bootstraper logo">
                    </div>
                    <h6 class="mb-4 text-muted">Update Class Data</h6>
                    <form action="class_update_data.php" method="post">
                          <div class="mb-3 text-start">
                            
                            <input type="hidden" class="form-control"  name="class_id" value="<?php echo $class_id;?>">
                        </div>
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Class Name</label>
                            <input type="text" class="form-control" placeholder="Class Name" name="class_name" value="<?php echo $class_name;?>" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Is Detail </label>
                            <select name="class_detail" required>
                            <option value="Open">Open</option>
                            <option value="Close">Close</option>
                            </select>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Calss Description </label>
                            <input type="text" class="form-control" placeholder="Class Description" name="class_desc" value="<?php echo $class_description;?>" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Course Name </label>
                            <select name="course_id" >
								<?php

									while ($rows = mysqli_fetch_array($result)):;
								?>
									<option value="<?php echo $rows[0];?>"><?php echo $rows[2];?></option>

									<?php  endwhile; ?>
                                     </select>
                        </div>                         
                        <button class="btn btn-primary shadow-2 mb-4" name="enter">Upate Class</button>
                    </form>
                    <p class="mb-2 text-muted">View Class Data<a href="view_class.php">Click Here!</a></p>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>