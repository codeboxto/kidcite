<?php
if (isset($_POST["enter"]))
{
	$kidicite_config=mysqli_connect("localhost","root","","kidicite");
	$student_code=$_POST["student_code"];
	$student_name=$_POST["student_name"];    
	$student_phone=$_POST["student_phone"];
	$student_email=$_POST["student_email"]; 
	$student_password=$_POST["student_password"];
	$gender=$_POST["gender"];    
	$student_dob=$_POST["student_dob"];
	$student_nrc=$_POST["student_nrc"];      
	$student_status=$_POST["student_status"];    
    
	$batch_info_sql = "INSERT INTO student(student_code,student_name,student_phone,student_email,student_password,gender,date_of_birth,nrc_no,student_status) 
	VALUES ('$student_code','$student_name','$student_phone','$student_email','$student_password','$gender','$student_dob','$student_nrc','$student_status')";

    if ($kidicite_config->query($batch_info_sql) === TRUE) {
       header ("location:view_student_date.php");
    } else {
        echo "Failed insert:".mysqli_connect_error($kidicite_config);

}
}
?>