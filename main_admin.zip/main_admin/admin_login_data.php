<?php
session_start();
	$kidicite_config=mysqli_connect("localhost","root","","kidicite");
			$a_email = $_POST["admin_email"];
			$a_password = $_POST["admin_password"];
            $login_date= date('Y-m-d');
            $today = date("H:i:s"); 

    echo "$login_time";
$sql= $kidicite_config->query("Select * from admin where email='$a_email' && password='$a_password' "); 

if (mysqli_num_rows($sql) > 0)
    {
    while($row = mysqli_fetch_assoc($sql))
     {
        $_SESSION['member_id']=$row['member_id'];      
        $_SESSION['member_name']=$row['member_name'];
 $member_id=$_SESSION['member_id'];
$member_name= $_SESSION['member_name'];
       
     }
 header ("location:index.php");
}
 
else 
{
   header ("location:member_register.php");

    }

	?>