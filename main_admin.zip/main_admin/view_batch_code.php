<!doctype html>
<!-- 
* Bootstrap Simple Admin Template
* Version: 2.1
* Author: Alexis Luna
* Website: https://github.com/alexis-luna/bootstrap-simple-admin-template
-->
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Kidicite &mdash; View Class Detail Page</title>
    <link href="assets/vendor/fontawesome/css/fontawesome.min.css" rel="stylesheet">
    <link href="assets/vendor/fontawesome/css/solid.min.css" rel="stylesheet">
    <link href="assets/vendor/fontawesome/css/brands.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/datatables/datatables.min.css" rel="stylesheet">
    <link href="assets/css/master.css" rel="stylesheet">
</head>

<body>
    <div class="wrapper">
        <!-- sidebar navigation component -->
      <nav id="sidebar" class="active">
            <div class="sidebar-header">
                <img src="assets/img/logo_transparent.png" width="50px" height="50px" alt="bootraper logo" class="app-logo">
            </div>
            <ul class="list-unstyled components text-secondary">
                <li>
                    <a href="index.html"><i class="fas fa-home"></i> Admin Home Page</a>
                </li>
                <li>
                    <a href="student.html"><i class="fas fa-table"></i> Students</a>
                </li>
                <li>
                    <a href="charts.html"><i class="fas fa-chart-bar"></i>Newsletters</a>
                </li>

                            <li>
                    <a href="#uielementsmenu" data-bs-toggle="collapse" aria-expanded="false" class="dropdown-toggle no-caret-down"><i class="fas fa-layer-group"></i> Data Insert</a>
                    <ul class="collapse list-unstyled" id="uielementsmenu">
                        <li>
                            <a href="course.html"><i class="fas fa-angle-right"></i> Course</a>
                        </li>
                        <li>
                            <a href="class.php"><i class="fas fa-angle-right"></i> Class</a>
                        </li>
                        <li>
                            <a href="class_detail.php"><i class="fas fa-angle-right"></i> Class Details</a>
                        </li>
                        <li>
                            <a href="batch_code.php"><i class="fas fa-angle-right"></i>Batch </a>
                        </li>
                         <li>
                            <a href="course_detail.php"><i class="fas fa-angle-right"></i> Course Detail</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#authmenu" data-bs-toggle="collapse" aria-expanded="false" class="dropdown-toggle no-caret-down"><i class="fas fa-user-shield"></i> Authentication</a>
                    <ul class="collapse list-unstyled" id="authmenu">
                        <li>
                            <a href="login.html"><i class="fas fa-lock"></i> Login</a>
                        </li>
                        <li>
                            <a href="signup.html"><i class="fas fa-user-plus"></i> Signup</a>
                        </li>
                        <li>
                            <a href="forgot-password.html"><i class="fas fa-user-lock"></i> Forgot password</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="users.html"><i class="fas fa-user-friends"></i>Staffs</a>
                </li>
                <li>
                    <a href="settings.html"><i class="fas fa-cog"></i>Settings</a>
                </li>
            </ul>
        </nav>
        <!-- end of sidebar component -->
        <div id="body" class="active">
            <!-- navbar navigation component -->
            <nav class="navbar navbar-expand-lg navbar-white bg-white">
                <button type="button" id="sidebarCollapse" class="btn btn-light">
                    <i class="fas fa-bars"></i><span></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="nav navbar-nav ms-auto">
                        <li class="nav-item dropdown">
                            <div class="nav-dropdown">
                                <a href="#" id="nav1" class="nav-item nav-link dropdown-toggle text-secondary" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-link"></i> <span>Quick Links</span> <i style="font-size: .8em;" class="fas fa-caret-down"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end nav-link-menu" aria-labelledby="nav1">
                                    <ul class="nav-list">
                                        <li><a href="" class="dropdown-item"><i class="fas fa-list"></i> Access Logs</a></li>
                                        <div class="dropdown-divider"></div>
                                        <li><a href="" class="dropdown-item"><i class="fas fa-database"></i> Back ups</a></li>
                                        <div class="dropdown-divider"></div>
                                        <li><a href="" class="dropdown-item"><i class="fas fa-cloud-download-alt"></i> Updates</a></li>
                                        <div class="dropdown-divider"></div>
                                        <li><a href="" class="dropdown-item"><i class="fas fa-user-shield"></i> Roles</a></li>
                                    </ul>
                                </div>
                            </div>
                        </li>
                        <li class="nav-item dropdown">
                            <div class="nav-dropdown">
                                <a href="#" id="nav2" class="nav-item nav-link dropdown-toggle text-secondary" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-user"></i> <span>John Doe</span> <i style="font-size: .8em;" class="fas fa-caret-down"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end nav-link-menu">
                                    <ul class="nav-list">
                                        <li><a href="" class="dropdown-item"><i class="fas fa-address-card"></i> Profile</a></li>
                                        <li><a href="" class="dropdown-item"><i class="fas fa-envelope"></i> Messages</a></li>
                                        <li><a href="" class="dropdown-item"><i class="fas fa-cog"></i> Settings</a></li>
                                        <div class="dropdown-divider"></div>
                                        <li><a href="" class="dropdown-item"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                                    </ul>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
            <!-- end of navbar navigation -->
            <div class="content">
                <div class="container">
                    <div class="page-title">
                        <h3>Batch 
                        </h3>
                    </div>
                    <div class="box box-primary">                
                        <div class="box-body">
                            <?php
             $kidicite_config=mysqli_connect("localhost","root","","kidicite");
               $sql=$kidicite_config->query("select batch_code.batch_id,batch_code.batch_name, batch_code.start_date,batch_code.end_date, class_detail.class_detail_name from batch_code ,class_detail where class_detail.class_detail_id=batch_code.class_detail_id" ); 
                            
                         echo"<table width='100%' class='table table-hover' id='dataTables-example'>
                                    <thead>
                                    <tr>
                                        <th>Batch ID</th>
                                        <th>Batch Name</th>
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                        <th>Class Detail Name</th>                                        
                                        <th></th>
                                    </tr>
                                </thead>"  ; 
                                while($row=$sql->fetch_assoc())
                                {	
                    $c1=$row['batch_id']; 
                    $c2=$row['batch_name'];
				    $c3=$row['start_date'];
                    $c4=$row['end_date'];
				    $c5=$row['class_detail_name'];                                     
			
					echo "           <tbody>
                                    <tr>
                                        <td>$c1</td>
                                        <td>$c2</td>
                                        <td>$c3</td>
                                        <td>$c4</td>
                                        <td>$c5</td>                                      
               
                                        <td class='text-end'>
                                            <a href=\"batch_update.php? 
                                            batch_id=$c1 
                                            & batch_name=$c2
                                            & start_date=$c3
                                            & end_date=$c4
                                            & class_detail_name=$c5\"
                                          class='btn btn-outline-info btn-rounded'><i class='fas fa-pen'></i></a>
                                            <a href='delete.php'/? class='btn btn-outline-danger btn-rounded'><i class='fas fa-trash'></i></a>
                                        </td>"
                    ;
                    
					 echo"
					 		 </tr>
                        
                                </tbody>"; 
					}
                    
                                   
                           	echo  "</table>";
                                ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/datatables/datatables.min.js"></script>
    <script src="assets/js/initiate-datatables.js"></script>
    <script src="assets/js/script.js"></script>
</body>

</html>