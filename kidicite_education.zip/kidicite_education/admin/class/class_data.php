<?php
if (isset($_POST["enter"]))
{
	require("../kidicite_config.php");
	$class_name=$_POST["class_name"];
	$class_detail=$_POST["class_detail"];    
	$class_desc=$_POST["class_desc"];
	$subject_id=$_POST["subject_id"];  
    
	$class_info_sql = "INSERT INTO class(class_name,class_detail,class_description,s_id) 
	VALUES ('$class_name','$class_detail','$class_desc','$subject_id')";

    if ($kidicite_config->query($class_info_sql) === TRUE) {
       header ("location:view_student_batch.php");
    } else {
        echo "Failed insert:".mysqli_connect_error($kidicite_config);

}
}
?>