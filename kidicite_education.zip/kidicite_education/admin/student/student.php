<?php
session_start();
$name=$_SESSION['name'];       
$email=$_SESSION['email'];
$password= $_SESSION['password'];
require("../kidicite_config.php");
$sql="Select admin_email,admin_password from admin where admin_email='$email' && admin_password='$password'";
$result= $kidicite_config->query($sql);
if(!$result)
{
    echo "Error updating record: " . $kidicite_config->error;
}

?>
<!doctype html>

<html lang="en">

<head>
      <!--header-->
      <?php include("../assets/header_links/form_header.php");?>
    <!-- End of header -->
    <title>Kidicite &mdash; Student Register Page</title>
    
</head>

<body>
    <div class="wrapper">
        <div class="auth-content">
            <div class="card">
                <div class="card-body text-center">
                    <div class="mb-4">
                        <img class="brand" src="../assets/img/logo_transparent.png" width="120px" height="120px" alt="bootstraper logo">
                    </div>
                    <h6 class="mb-4 text-muted">Register Student Data</h6>
                    <form action="student_register.php" method="post">
                        <div class="mb-3 text-start">
                            <label for="id" class="form-label">Student Code</label>
                            <input type="text" class="form-control" placeholder="Enter Student Code" name="student_code" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Student Name</label>
                            <input type="text" class="form-control" placeholder="Student Name" name="student_name"  required>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="phone" class="form-label">Student Phone Number</label>
                            <input type="text" class="form-control" placeholder="Enter Student Phone Number" name="student_phone"  required>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="email" class="form-label">Student Email</label>
                            <input type="email" class="form-control" placeholder="Student Email"  name="student_email" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="password" class="form-label">Student Password</label>
                            <input type="password" class="form-control" placeholder="Enter Student Password" name="student_password"  required>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="gender" class="form-label">Student Gender</label>
                            <select  name="gender"  class="form-select" required>    
                            <option value="male">Male</option>
                            <option value="female">Female</option></select> 
                        </div>
                        <div class="mb-3 text-start">
                            <label for="dob" class="form-label">Student DoB</label>
                            <input type="date" class="form-control" name="student_dob" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="nrc" class="form-label">Student NRC</label>
                            <input type="text" class="form-control" placeholder="Student NRC" name="student_nrc" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="status" class="form-label">Student Status</label>
                             <select name="student_status" class="form-select"  required>   
                            <option value="attending">Attending</option>
                            <option value="not_attending">Not Attending</option>
                            </select> 
                        </div>                      
                        <button class="btn btn-primary shadow-2 mb-4" name="enter">Register</button>
                    </form>
                    <button class="btn btn-success shadow-2 mb-4"><a href="view_course.php">Back To View Course</a></button>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>