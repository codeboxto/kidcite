<?php
if (isset($_POST["enter"]))
{
	$kidicite_config=mysqli_connect("localhost","root","","kidicite");
	$batch_code_name=$_POST["batch_code"];
	$s_date=$_POST["start_date"];    
	$e_date=$_POST["end_date"];
	$class_detail_id=$_POST["class_detail_id"];  
    
	$batch_info_sql = "INSERT INTO batch_code(batch_name,start_date,end_date,class_detail_id) 
	VALUES ('$batch_code_name','$s_date','$e_date','$class_detail_id')";

    if ($kidicite_config->query($batch_info_sql) === TRUE) {
       header ("location:view_batch_code.php");
    } else {
        echo "Failed insert:".mysqli_connect_error($kidicite_config);

}
}
?>