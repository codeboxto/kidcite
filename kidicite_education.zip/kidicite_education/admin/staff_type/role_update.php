
<!Doctype html>

<html lang="en">

<head>
      <!--header-->
      <?php include("../assets/header_links/form_header.php");?>
    <!-- End of header -->
    <title>Kidicite &mdash; Staff Type Update Page</title>
    
</head>
                    <?php
$id = "";                    
$staff_type_id = "";
$role = "";

require("../kidicite_config.php");
$id =  isset($_GET['id'])? $_GET['id'] : "";
$staff_type_id= isset($_GET['staff_type_id'])? $_GET['staff_type_id'] : ""; 
$role = isset($_GET['role'])? $_GET['role'] : ""; 
  
?>
<body>
    <div class="wrapper">
        <div class="auth-content">
            <div class="card">
                <div class="card-body text-center">
                    <div class="mb-4">
                        <img class="brand" src="../assets/img/logo_transparent.png" width="120px" height="120px" alt="bootstraper logo">
                    </div>
                    <h6 class="mb-4 text-muted">Update Staff Type Data</h6>
                    <form action="role_update_data.php" method="post">
                          <div class="mb-3 text-start">
                            
                            <input type="hidden" class="form-control"  name="stype_id" value="<?php echo $id;?>">
                        </div>
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Class Name</label>
                            <input type="text" class="form-control" placeholder="Staff Type Code" name="staff_type_id" value="<?php echo $staff_type_id;?>" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Calss Description </label>
                            <input type="text" class="form-control" placeholder="Role" name="role" value="<?php echo $role;?>" required>
                        </div>
                       
                        <button class="btn btn-primary shadow-2 mb-4" name="enter">Upate Staff Type</button>
                    </form>
                    <button class="btn btn-success shadow-2 mb-4"><a href="view_role.php">Back To View Staff Type</a></button>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>