<?php
require("../kidicite_config.php");

$s_id=$_POST['sid'];
$subject_id=$_POST['subject_id'];
$s_name=$_POST['subject_name'];
$s_status=$_POST['subject_status'];


	$update_result=mysqli_query($kidicite_config," UPDATE subject SET  
	subject_id='$subject_id',
	subject_name='$s_name',
    subject_status='$s_status'
    WHERE s_id='$s_id'");
	if($update_result)
	{
	header('Location:view_subject.php');
	}
else
	{
	echo "No Data";
	}
?>