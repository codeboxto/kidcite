<?php include("header.php");?>
<nav id="sidebar" class="active">
            <div class="sidebar-header">
                <img src="../assets/img/logo_transparent.png" width="50px" height="50px" alt="bootraper logo" class="app-logo">
            </div>
            <ul class="list-unstyled components text-secondary">
                <li>
                    <a href="../authentication/admin_home.php"><i class="fas fa-home"></i> Home Page</a>
                </li>
                <li>
                    <a href="../student/view_student_data.php"><i class="fas fa-table"></i> Students</a>
                </li>
                <li>
                    <a href="../student_batch/view_student_batch.php"><i class="fas fa-table"></i> Students Batch</a>
                </li>               
                <li>
                    <a href="#uielementsmenu" data-bs-toggle="collapse" aria-expanded="false" class="dropdown-toggle no-caret-down">
                        <i class="fas fa-layer-group"></i> Click this link to insert data</a><ul class="collapse list-unstyled" id="uielementsmenu">
                        <li>
                            <a href="../subject/view_subject.php"><i class="fas fa-angle-right"></i> Subject</a>
                        </li>
                        <li>
                            <a href="../class/view_class.php"><i class="fas fa-angle-right"></i> Class</a>
                        </li>
                        <li>
                            <a href="../class_detail/view_class_detail.php"><i class="fas fa-angle-right"></i> Class Details</a>
                        </li>
                        <li>
                            <a href="../batch/view_batch_code.php"><i class="fas fa-angle-right"></i>Batch </a>
                        </li>
                         <li>
                            <a href="../subject_detail/view_subject_detail.php"><i class="fas fa-angle-right"></i> Subject Detail</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="../staff_type/view_role.php"><i class="fas fa-user-friends"></i>Staff Type</a>
                </li>
                <li>
                    <a href="../staff/view_staff.php"><i class="fas fa-user-friends"></i>Staffs</a>
                </li>
            </ul>
        </nav>