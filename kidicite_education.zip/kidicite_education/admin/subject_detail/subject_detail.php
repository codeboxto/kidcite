<?php
require("../kidicite_config.php");
$sql_class_detail="select * from class_detail";
$result=mysqli_query($kidicite_config,$sql_class_detail);

?>
<?php
include 'subject_detail_data.php';
?>
<!Doctype html>
<html lang="en">

<head>
      <!--header-->
      <?php include("../assets/header_links/form_header.php");?>
    <!-- End of header -->
    <title>Kidicite &mdash; Subject Page</title>
    
</head>

<body>
    <div class="wrapper">
        <div class="auth-content">
            <div class="card">
                <div class="card-body text-center">
                    <div class="mb-4">
                        <img class="brand" src="../assets/img/logo_transparent.png" width="120px" height="120px" alt="bootstraper logo">
                    </div>
                    <h6 class="mb-4 text-muted">Register Subject Detail</h6>
                    <form action="subject_detail_data.php" method="post" enctype="multipart/form-data">
                    <div class="mb-3 text-start">
                            <label for="name" class="form-label">Class Detail Name </label>
                            <select name="class_detail_id"  class="form-select" >
								<?php

									while ($rows = mysqli_fetch_array($result)):;
								?>
									<option value="<?php echo $rows[0];?>"><?php echo $rows[1];?></option>

									<?php  endwhile; ?>
                                     </select>
                        </div> 
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Subject Detail Type</label>
                            <select name="subject_detail_type" class="form-select" required >
                            <option value="pdf">PDF File</option>
                            <option value="audio">Audio File</option>
                            </select> 
                        </div>
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">File</label>
                            <input type="file" class="form-control" placeholder="Batch Name" name="myfile" required>
                        </div>

                       
                        <button class="btn btn-primary shadow-2 mb-4" name="enter">Reigster Subject Detail </button>
                    </form>
                    <p class="mb-2 text-muted">View Subject Detail<a href="view_subject_detail.php">Click Here!</a></p>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>