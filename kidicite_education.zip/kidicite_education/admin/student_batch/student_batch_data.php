<?php
if (isset($_POST["enter"]))
{
	require("../kidicite_config.php");
	$student_id=$_POST["student_id"];
	$batch_id=$_POST["batch_id"];    
	$join_date=$_POST["join_date"];
	$active_status=$_POST["active_status"];  
    
	$class_info_sql = "INSERT INTO student_batch(student_id,batch_id,join_date,active_status) 
	VALUES ('$student_id','$batch_id','$join_date','$active_status')";

    if ($kidicite_config->query($class_info_sql) === TRUE) {
       header ("location:view_student_batch.php");
    } else {
        echo "Failed insert:".mysqli_connect_error($kidicite_config);

}
}
?>