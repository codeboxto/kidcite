<?php

session_start();
if(!isset($_SESSION['student_id'], $_SESSION['batch_id'] ) ){
header("location:jap_show_stubject.php");
}
?>
<?php
$student_name=$_SESSION['name'];   
?>	    

<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />    
	<title>Kidicite &mdash; Mission and Vision Page</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto+Slab:300,400" rel="stylesheet">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">

	<!-- Flexslider  -->
	<link rel="stylesheet" href="css/flexslider.css">

	<!-- Pricing -->
	<link rel="stylesheet" href="css/pricing.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->
	<link rel="stylesheet" href="css/table_style.css">
	</head>
	<body id="body">
		
	<div class="fh5co-loader"></div>
	
	<div id="page">
	<?php include('links/inner_navigation.php');?>
	
			
	<aside id="fh5co-hero">
		<div class="flexslider">
			<ul class="slides">

		   	<li style="background-image: url(images/instructor.webp);">


		   		<div class="overlay-gradient"></div>
		   		<div class="container">
		   			<div class="row">
			   			<div class="col-md-8 col-md-offset-2 text-center slider-text">
			   				<div class="slider-text-inner">
			   					<h1>Welcom! Dear <?php echo $student_name;?></h1>
			   				</div>
			   			</div>
			   		</div>
		   		</div>
		   	</li>
		  	</ul>
	  	</div>
	</aside>
	<div id="fh5co-staff">
		<div class="container">
			<div class="row">
		
				
						
						<table id='subjects'>
						<?php 
						$displayCount = 1; 
						include("kidicite_config.php");
						$sql = "SELECT subject_detail_id, class_detail_id,subject_detail_type,files_name from subject_detail 
						where class_detail_id='1' && subject_detail_type='pdf'";
						$result = mysqli_query($kidicite_config, $sql);
						
						while ($row= $result->fetch_assoc()){

							if(($displayCount % 3) == 1){
								echo '<tr>';
							}
							echo '<td>';
						?>
						<img src="images/52.png" alt="PDF Image" width="100px" height="100px">
						
						 <h3><?php echo $row['files_name']; ?>
						 <a href="download_pdf.php?subject_detail_id=<?php echo $row['subject_detail_id']; ?>">Download</a></h3>
						
						<?php
                           echo '</td>';
                           if(($displayCount % 3) == 0){
                               echo '</tr>';
                           }
                           $displayCount++;
                       }
                    ?>
						</table>
					
		
			</div>
		</div>
	</div>


<footer id="fh5co-footer" role="contentinfo" style="background-image: url(images/image_11.jpg);">
		<div class="overlay"></div>
		<div class="container">
			<div class="row row-pb-md">
				<div class="col-md-3 fh5co-widget">
					<h3>About Education</h3>
					<p> Education means inculcating moral values, positive thinking, attitude of helping, attitude of giving to society and ethical values these kind of students are only able to bring changes in society. </p>
				</div>
				<div class="col-md-2 col-sm-4 col-xs-6 col-md-push-1 fh5co-widget">
					<h3>Learning</h3>
					<ul class="fh5co-footer-links">
						<li><a href="#">English</a></li>
						<li><a href="#">Computer Basic</a></li>
						<li><a href="#">Language</a></li>
					</ul>
				</div>

				<div class="col-md-2 col-sm-4 col-xs-6 col-md-push-1 fh5co-widget">
					<h3>English Course</h3>
					<ul class="fh5co-footer-links">
						<li><a href="#">Normal Class</a></li>
						<li><a href="#">Speaking Class</a></li>

					</ul>
				</div>

				<div class="col-md-2 col-sm-4 col-xs-6 col-md-push-1 fh5co-widget">
					<h3>Normal Class</h3>
					<ul class="fh5co-footer-links">
						<li><a href="#">Foundation</a></li>
						<li><a href="#">Pre A1 starter</a></li>
						<li><a href="#">A1 Remover</a></li>
						<li><a href="#">A2 Flyer</a></li>
					</ul>
				</div>

				<div class="col-md-2 col-sm-4 col-xs-6 col-md-push-1 fh5co-widget">
					<h3>Computer Basic</h3>
					<ul class="fh5co-footer-links">
						<li><a href="#">Basic</a></li>
						<li><a href="#">Computer Science</a></li>
						<li><a href="#">Programming</a></li>
					</ul>
				</div>
			</div>

			<div class="row copyright">
				<div class="col-md-12 text-center">
					<p>
						<small class="block">&copy; 2016 Free HTML5. All Rights Reserved.</small> 
						<small class="block">Designed by <a href="http://freehtml5.co/" target="_blank">FreeHTML5.co</a> Demo Images: <a href="http://unsplash.co/" target="_blank">Unsplash</a> &amp; <a href="https://www.pexels.com/" target="_blank">Pexels</a></small>
					</p>
				</div>
			</div>

		</div>
	</footer>
	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Stellar Parallax -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- Flexslider -->
	<script src="js/jquery.flexslider-min.js"></script>
	<!-- countTo -->
	<script src="js/jquery.countTo.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Count Down -->
	<script src="js/simplyCountdown.js"></script>
	<!-- Main -->
	<script src="js/main.js"></script>
	<script>
    var d = new Date(new Date().getTime() + 1000 * 120 * 120 * 2000);

    // default example
    simplyCountdown('.simply-countdown-one', {
        year: d.getFullYear(),
        month: d.getMonth() + 1,
        day: d.getDate()
    });

    //jQuery example
    $('#simply-countdown-losange').simplyCountdown({
        year: d.getFullYear(),
        month: d.getMonth() + 1,
        day: d.getDate(),
        enableUtc: false
    });
	</script>
	</body>
</html>

