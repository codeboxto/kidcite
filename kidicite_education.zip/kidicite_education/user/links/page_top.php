<div class="top">
			<div class="container">
				<div class="row">
					<div class="col-xs-12 text-right">
						<p class="site">techkidicite@gmail.com</p>
						<p class="num">Phone: 09-483 023 430</p>
						<ul class="fh5co-social">
							<li><a href="#"><i class="icon-facebook2"></i></a></li>
							<li><a href="#"><i class="icon-twitter2"></i></a></li>
						</ul>
				</div>
				</div>
			</div>
		</div>
        .fh5co-nav .top {
  border-bottom: 1px solid #000;
  padding: 0px 0;
  margin-bottom: 0;
}
.fh5co-nav .top .num, .fh5co-nav .top .fh5co-social, .fh5co-nav .top .site {
  display: inline-block;
  margin: 0;
  padding: 5px 12px;
}
@media screen and (max-width: 768px) {
  .fh5co-nav .top .num, .fh5co-nav .top .fh5co-social, .fh5co-nav .top .site {
    padding: 5px 10px;
  }
}
.fh5co-nav .top .site {
  float: left;
  font-weight: 300;
  margin-top: 0px;
  border-left: 1px solid #000;
  border-right: 1px solid #000;
}
@media screen and (max-width: 480px) {
  .fh5co-nav .top .site {
    display: none;
  }
}
.fh5co-nav .top .num {
  color: #000;
  font-size: 17px;
  letter-spacing: 0px;
  border-left: 1px solid #000;
}
.fh5co-nav .top .fh5co-social {
  margin: 0;
  border-left: 1px solid #000;
  border-right: 1px solid #000;
}
.fh5co-nav .top .fh5co-social li {
  font-size: 16px;
  display: inline-block;
}
.fh5co-nav .top .fh5co-social li a {
  padding: 7px 7px;
}
.fh5co-nav .top .fh5co-social li a i {
  font-size: 14px;
}