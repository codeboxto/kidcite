<nav class="fh5co-nav" role="navigation">

		<div class="top-menu">
			<div class="container">
				<div class="row">
					<div class="col-xs-2">
						<div id="fh5co-logo">
                            <a href="index.php">
                           <img src="images/logo_transparent.png" alt="page-icon" width="100px" height="100px">
                            </a></div>
					</div>
					<div class="col-xs-10 text-right menu-1">
						<ul>
							<li class="active"><a href="index.php">Home</a></li>
							<li><a href="about.php">About</a></li>
							<li class="has-dropdown">
								<a href="#">Management Team</a>
								<ul class="dropdown">
									<li><a href="mission_and_vision.php">Mission and vision</a></li>
									<li><a href="#">Our Standard</a></li>
									<li><a href="#">Careers</a></li>
									<li><a href="#">Contanct Us</a></li>
								</ul>
							</li>
							<li><a href="subjects.php">Subjects</a></li>
							<li><a href="pricing.php">Blogs</a></li>
							<li class="btn-cta"><a href="../admin/authentication/admin_login.php"><span>Login</span></a></li>
							<li class="btn-cta"><a href="signin.php"><span>Signin</span></a></li>
						</ul>
					</div>
				</div>
				
			</div>
		</div>
	</nav>