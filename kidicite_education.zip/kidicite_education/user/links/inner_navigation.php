<nav class="fh5co-nav" role="navigation">

		<div class="top-menu">
			<div class="container">
				<div class="row">
					<div class="col-xs-2">
						<div id="fh5co-logo">
                            <a href="index.php">
                           <img src="images/logo_transparent.png" alt="page-icon" width="100px" height="100px">
                            </a></div>
					</div>
					<div class="col-xs-10 text-right menu-1">
						<ul>
							<li class="active"><a href="index.php">Home</a></li>
							<li class="has-dropdown">
								<a href="#">English Subjects</a>
								<ul class="dropdown">
									<li><a href="Foundation">Foundation</a></li>
									<li><a href="#">Our Standard</a></li>
									<li><a href="#">Careers</a></li>
									<li><a href="#">Contanct Us</a></li>
								</ul>
							</li>
							<li class="has-dropdown">
								<a href="#">Mathematics</a>
								<ul class="dropdown">
									<li><a href="#">Careers</a></li>
									<li><a href="#">Contanct Us</a></li>
								</ul>
							</li>  
                            <li class="has-dropdown">
								<a href="#">Computer Science</a>
								<ul class="dropdown">
									<li><a href="#">Senior</a></li>
									<li><a href="#">Junior</a></li>
								</ul>
							</li> 
                            <li class="has-dropdown">
								<a href="#">Aaia Language</a>
								<ul class="dropdown">
									<li><a href="#">Chinese</a></li>
									<li><a href="#">Korea</a></li>
									<li><a href="#">Japanese</a></li>
								</ul>
							</li>                                                                               
							<li class="btn-cta"><a href="logout.php"><span>Logout</span></a></li>
						</ul>
					</div>
				</div>
				
			</div>
		</div>
	</nav>