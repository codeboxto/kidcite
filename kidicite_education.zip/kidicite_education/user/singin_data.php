<?php

session_start();

if(isset($_POST['enter']))
{   
    $s_name = $_POST["student_name"];
    $s_email = $_POST['student_email'];
    $s_password = $_POST['student_password'];

 include("kidicite_config.php");
$sql= $kidicite_config->query("Select s.student_id,s.student_name,s.student_email,s.student_password ,sb.batch_id
from student s, student_batch sb
where s.student_name='$s_name' && s.student_email='$s_email' && s.student_password='$s_password' && s.student_id=sb.student_id "); 

if (mysqli_num_rows($sql) > 0)
{
while($row = mysqli_fetch_assoc($sql))
{
$_SESSION['student_id']=$row['student_id'];    
$_SESSION['name']=$row['student_name']; 
$_SESSION['email']=$row['student_email'];      
$_SESSION['password']=$row['student_password'];
$_SESSION['batch_id']=$row['batch_id']; 
$student_id=$_SESSION['student_id'];  
$name=$_SESSION['name'];       
$email=$_SESSION['email'];
$password= $_SESSION['password'];
$batch_id=$_SESSION['batch_id'];  

}

header ("location:jap_show_subject.php");
}

else 
{
    echo "<script>alert('Please Signin Again'); window.location = 'signin.php';</script>";


}
}
			

	?>