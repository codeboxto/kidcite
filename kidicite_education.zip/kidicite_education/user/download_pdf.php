<?php// Downloads files
    
    $subject_detail = $_GET['subject_detail_id'];
    var_dump("testing");



    $sql = "SELECT subject_detail_id  from subject_detail where subject_detail_id='$subject_detail_id' ";
    
    $result = mysqli_query($kidicite_config, $sql);

    $file = mysqli_fetch_assoc($result);
    $filepath = '../admin/upload/' . $file['files_name'];

    if (file_exists($filepath)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename=' . basename($filepath));
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize('../admin/upload/' . $file['files_name']));
        readfile('../admin/upload' . $file['files_name']);

        echo $file;
        die();

        
        
        $newCount = $file['downloads'] + 1;
        $updateQuery = "UPDATE subject_detail SET downloads=$newCount WHERE subject_detail_id=$id";
        mysqli_query($kidicite_config, $updateQuery);
        exit;
    }
   else
   {
    echo "success";
   }
 



?>
